from django.db import models


class List(models.Model):
    production_companies = models.CharField(max_length=50, verbose_name='제작사명',default='')
    name = models.CharField(max_length=10, verbose_name='작품명',default='')
    first_air_day = models.DateField(verbose_name='첫 방영일')
    last_air_day = models.DateField( verbose_name='마지막 방영일')
    actor = models.CharField(max_length=80, verbose_name='배우',default='')
    sentiment = models.CharField(max_length=10, verbose_name='예측',default='')
            
    def __str__(self):
        return self.production_companies + "("+ self.name + ")"
    
    def get_absolute_url(self):
        return f'/lists/{self.id}/'
    
    class Meta:
        db_table = 'Company_List'
        verbose_name = '제작사 목록'
        verbose_name_plural = '제작사 목록'
        
