from django.shortcuts import get_object_or_404, render, redirect
from django.views.generic.list import ListView
from .models import List
from django.views import generic
from django.db.models import Q

class CompanyList(generic.ListView):
    model = List
    context_object_name = 'company_list'
    template_name = 'lists/company_list.html'
    
    def queryset(self):
        return List.objects.all()    
    
    
    
class CompanyDetail(generic.DetailView):
    model = List
    context_object_name = 'company_detail'
    template_name = 'lists/company_detail.html'
    
    def get_object(self):
        return get_object_or_404(List, id=self.kwargs.get('id'))
    
    

# Create your views here.
