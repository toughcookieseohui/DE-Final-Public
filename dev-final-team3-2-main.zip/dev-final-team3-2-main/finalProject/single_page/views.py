from django.shortcuts import render

def landing(request):
    return render(request, 'single_page/landing.html')
# Create your views here.