import requests
import json
from dotenv import load_dotenv
import os

load_dotenv()
bearer_token = os.getenv('TMDB_BEARER_TOKEN')

def get_id_list() :
    url = "https://api.themoviedb.org/3/discover/tv"
    headers = {
        "accept": "application/json",
        "Authorization": f"Bearer {bearer_token}"
    }

    params = {
        "first_air_date_year": 2023,
        "include_adult": "true",
        "include_null_first_air_dates": "false",
        "language": "ko-KR",
        "page": 1,
        "sort_by": "popularity.desc",
        "with_original_language": "ko",
        "with_genres" : 18
    }

    response = requests.get(url, headers=headers, params=params)
    data = response.json()
    # print(response.text)


    total_pages = data['total_pages']

    all_dramas = data['results']

    for page in range(2, total_pages + 1) :
        params["page"] = page
        response = requests.get(url, headers=headers, params=params)
        data = response.json()
        all_dramas.extend(data['results'])

    id_list = []
    for item in all_dramas :
        id_list.append(item['id'])

    return id_list


def get_drama_details() :
    headers = {
        "accept": "application/json",
        "Authorization": f"Bearer {bearer_token}"
    }

    id_list = get_id_list()
    all_dramas_details = []

    for id in id_list : 
        url = f"https://api.themoviedb.org/3/tv/{id}"
        params = {
            "append_to_response" : "credits",
            "language" : "ko-KR"
        }

        response = requests.get(url, headers=headers, params=params)
        data = response.json()
        all_dramas_details.append(data)

    return all_dramas_details


with open('2023-dramadata.json', 'w', encoding='utf-8') as f :
    json.dump(get_drama_details(), f, ensure_ascii=False, indent=4)