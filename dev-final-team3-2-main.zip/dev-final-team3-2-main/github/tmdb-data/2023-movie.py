import requests
import json
from dotenv import load_dotenv
import os

load_dotenv()
bearer_token = os.getenv('TMDB_BEARER_TOKEN')


def get_id_list() :
    url = "https://api.themoviedb.org/3/discover/movie"

    headers = {
        "accept": "application/json",
        "Authorization": f"Bearer {bearer_token}"
    }

    params = {
        "include_adult": "true",
        "include_video": "false",
        "language": "ko-KR",
        "page": 1,
        "primary_release_year": 2023,
        "sort_by": "popularity.desc",
        "with_original_language": "ko"
    }

    response = requests.get(url, headers=headers, params=params)
    data = response.json()
    total_pages = data['total_pages']
    # print(data['results'])


    all_movies = data['results']

    for page in range(2, total_pages + 1):
        params["page"] = page 
        response = requests.get(url, headers=headers, params=params)
        data = response.json()
        all_movies.extend(data['results'])

    id_list = []
    for item in all_movies :
        id_list.append(item['id'])

    return id_list


def get_movie_details() :
    headers = {
        "accept": "application/json",
        "Authorization": f"Bearer {bearer_token}"
        }

    id_list = get_id_list()
    all_movies_details = []

    for id in id_list : 
        url = f"https://api.themoviedb.org/3/movie/{id}"
        params = {
            "append_to_response" : "credits",
            "language" : "ko-KR"
        }

        response = requests.get(url, headers=headers, params=params)
        data = response.json()
        all_movies_details.append(data)

    return all_movies_details



# json 파일로 저장
with open('2023-moviedata.json', 'w', encoding='utf-8') as f :
    json.dump(get_movie_details(), f, ensure_ascii=False, indent=4)