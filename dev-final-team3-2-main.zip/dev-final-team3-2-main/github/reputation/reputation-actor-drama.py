import requests
from bs4 import BeautifulSoup

brand_reputation = {}

for year in range(23, 25):
    for month in range(1, 13):
        if year == 24 and month > 2: 
            break
        url = f"https://brikorea.com/rk/drama{year:02}{month:02}"

        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')

        table = soup.find('table', class_='table table-bordered table-striped bri_rank_table')

        if table is None:
            print(f"{year:02}{month:02}")
            continue

        rows = table.find_all('tr')

        this_month = {}

        for row in rows:
            cols = row.find_all('td')
            
            if len(cols) > 3:
                name = cols[1].text
                score = int(cols[3].text.replace(',', ''))
                
                this_month[name] = score

        brand_reputation[f"{year:02}{month:02}"] = this_month

print(brand_reputation)
