import requests

url = "https://openapi.naver.com/v1/search/news.json"
params = {
    'query': '서울의 봄 영화'
}
headers = {
    'X-Naver-Client-Id': 'Q29sUDzaXC2mDznCO4_i',
    'X-Naver-Client-Secret': 'GQ3vaEEAs9'
}

response = requests.get(url, headers=headers, params=params)

if response.status_code == 200:
    data = response.json()
    print(f"{data['total']}")
else:
    print("Error Code:", response.status_code)
