
import requests

url = "https://www.googleapis.com/youtube/v3/search"
params = {
    'part': 'snippet',
    'maxResults': 25,
    'q': '#흥행',
    'key': 'AIzaSyAvtpmsdYA4VLGvCF7_tCBnJKzffNU7vMA'
}

response = requests.get(url, params=params)

if response.status_code == 200:
    data = response.json()
    video_ids = [item['id']['videoId'] for item in data['items'] if '#흥행' in item['snippet']['title'] or '#흥행' in item['snippet']['description']]
    print(video_ids)
    url = "https://www.googleapis.com/youtube/v3/videos"
    for video_id in video_ids:
        params = {
            'part': 'statistics',
            'id': video_id,
            'key': 'AIzaSyAvtpmsdYA4VLGvCF7_tCBnJKzffNU7vMA'
        }
        response = requests.get(url, params=params)

        if response.status_code == 200:
            data = response.json()
            print(data)
        else:
            print("Error Code:", response.status_code)
else:
    print("Error Code:", response.status_code)
