from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import time
import FinanceDataReader as fdr
import pandas as pd

chrome_options = Options()
chrome_options.add_argument("--headless") 

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

driver.get("https://m.stock.naver.com/domestic/theme/127")

# 페이지의 끝까지 스크롤 다운
body = driver.find_element(By.TAG_NAME, 'body')
for _ in range(3):
    body.send_keys(Keys.END)
    time.sleep(0.5)

# 종목 코드, 이름 추출
stock_codes = driver.find_elements(By.CLASS_NAME, "CommTable_code__2vSjg")
stock_names = driver.find_elements(By.CLASS_NAME, "CommTable_name__1LjLZ")

stock_info = [(code.text, name.text) for code, name in zip(stock_codes, stock_names)]

driver.quit()

all_stock_data = []

# 2023 주가정보 가져오기
for item in stock_info :
    stock_data = fdr.DataReader(item[0], start = '2023', end = '2024')
    stock_data['Code'] = item[0]
    stock_data['Name'] = item[1]
    stock_data = stock_data[['Code', 'Name', 'Open', 'High', 'Low', 'Close', 'Volume', 'Change']]

    all_stock_data.append(stock_data)

combined_stock_data = pd.concat(all_stock_data)
combined_stock_data.to_csv('2023-stockdata.csv', encoding='utf-8-sig')