from airflow import DAG
from airflow.operators.python import task
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.models import Variable
from airflow.utils.dates import days_ago
import requests
import datetime
import json
import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

default_args = {
    'owner': 'team3-2',
    'start_date': days_ago(1),
}

with DAG('naver_news_to_redshift', default_args=default_args, schedule_interval='@weekly') as dag:

    @task
    def get_drama_movie_titles():
        s3_hook = S3Hook(aws_conn_id='team3-2-s3-conn')
        bucket = 'team3-2-s3'
        drama_key = 'tmdb_data/2023-dramadata.json'
        movie_key = 'tmdb_data/2023-moviedata.json'

        drama_file_obj = s3_hook.get_key(drama_key, bucket)
        drama_file_content = drama_file_obj.get()['Body'].read()
        drama_data = json.loads(drama_file_content)
        drama_titles = [item['name'] for item in drama_data]

        movie_file_obj = s3_hook.get_key(movie_key, bucket)
        movie_file_content = movie_file_obj.get()['Body'].read()
        movie_data = json.loads(movie_file_content)
        movie_titles = [item['original_title'] for item in movie_data]

        kw_list = drama_titles + movie_titles

        return kw_list

    @task
    def get_naver_news_count(kw_list):
        url = "https://openapi.naver.com/v1/search/news.json"
        headers = {
            'X-Naver-Client-Id': Variable.get('navernews_client_id'),
            'X-Naver-Client-Secret': Variable.get('navernews_client_secret')
        }

        news_counts = {}

        for kw in kw_list:
            params = {'query': kw}
            response = requests.get(url, headers=headers, params=params)

            if response.status_code == 200:
                data = response.json()
                news_counts[kw] = data['total']
            else:
                raise Exception(f"Error Code: {response.status_code}")
        df = pd.DataFrame(list(news_counts.items()), columns=['Keyword', 'Count'])
        df.to_csv('/tmp/news_counts.csv', index=False)
        return '/tmp/news_counts.csv'

    @task
    def save_to_redshift(filename):
        df = pd.read_csv(filename)

        aws_conn_id = 'team3-2-redshift-conn'
        schema = 'public'
        table = 'naver_news'  

        postgres_hook = PostgresHook(aws_conn_id=aws_conn_id)
        engine = create_engine(postgres_hook.get_uri().replace("postgres", "postgresql+psycopg2", 1))
        Session = sessionmaker(bind=engine)
        session = Session()
        df.to_sql(table, schema=schema, con=session.get_bind(), if_exists='replace', index=False)

        session.commit()
        session.close()

    kw_list = get_drama_movie_titles()
    filename = get_naver_news_count(kw_list)
    save_to_redshift(filename)
