from airflow import DAG
from airflow.models import Variable
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.decorators import task
from datetime import datetime, timedelta
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
import requests
import pandas as pd
import json

@task
def generate_movie_data() :
    bearer_token = Variable.get("TMDB_BEARER_TOKEN")
    headers = {
    "accept": "application/json",
    "Authorization": f"Bearer {bearer_token}"
    }
    
    def get_company_id() :
        url = "https://api.themoviedb.org/3/search/company"

        stock_info = [('210120', '빅텐츠'), ('389140', '포바이포'), ('253450', '스튜디오드래곤'), ('200350', '래몽래인'), 
              ('036420', '콘텐트리중앙'), ('035900', 'JYP Ent.'), ('035760', 'CJ ENM'), ('048910', '대원미디어'), 
              ('054780', '키이스트'), ('122450', 'KX'), ('086980', '쇼박스'), ('241840', '에이스토리'), ('048550', 'SM C&C'), 
              ('322780', '코퍼스코리아'), ('034120', 'SBS'), ('051780', '큐로홀딩스'), ('432430', '와이랩'), ('035620', '바른손이앤에이'), 
              ('046390', '삼화네트웍스'), ('068050', '팬엔터테인먼트'), ('206560', '덱스터'), ('160550', 'NEW'), ('299900', '위지윅스 튜디오'),
              ('018700', '바른손'), ('036030', '케이티알파'), ('419530', 'SAMG엔터'), ('310200', '애니플러스'), ('317530', '캐리소프트'), 
              ('204630', '스튜오산타클로스'), ('289220', '자이언트스텝'), ('408900', '스튜디오미르'), ('173940', '에프엔씨엔터')]

        all_companies_info = []
        for item in stock_info :
            params = {
                "query" : item[1] #item[0] : 주식 코드, item[1] : 주식 이름
            }
            response = requests.get(url, headers=headers, params=params)
            data = response.json()
            for company in data['results'] :
                if 'id' in company and 'name' in company and company['origin_country'] == 'KR' :
                    company_info = (company['id'], company['name'])
                    all_companies_info.append(company_info)

        print(all_companies_info, len(all_companies_info))
        return all_companies_info


    def get_movie_id_list() :
        url = "https://api.themoviedb.org/3/discover/movie"

        company_list = get_company_id()
        company_ids = '|'.join([str(company[0]) for company in company_list])
        params = {
            "include_adult": "true",
            "include_video": "false",
            "language": "ko-KR",
            "page": 1,
            "primary_release_date.gte": '2023-01-01',
            "sort_by": "popularity.desc",
            "with_original_language": "ko",
            "with_companies" : company_ids
        }

        response = requests.get(url, headers=headers, params=params)
        data = response.json()
        total_pages = data['total_pages']

        all_movies = data['results']

        for page in range(2, total_pages + 1):
            params["page"] = page 
            response = requests.get(url, headers=headers, params=params)
            data = response.json()
            all_movies.extend(data['results'])

        id_list = []
        for item in all_movies :
            id_list.append(item['id'])

        print(len(all_movies))
        return id_list

    def get_movie_details() :
        id_list = get_movie_id_list()
        all_movies_details = []

        for id in id_list : 
            url = f"https://api.themoviedb.org/3/movie/{id}"
            params = {
                "append_to_response" : "credits",
                "language" : "ko-KR"
            }

            response = requests.get(url, headers=headers, params=params)
            data = response.json()
            all_movies_details.append(data)

        return all_movies_details
    
    filename = '/tmp/2023-2024-moviedata.json'
    with open(filename, 'w', encoding='utf-8') as f :
        json.dump(get_movie_details(), f, ensure_ascii=False, indent=4)

    return filename

@task
def upload_to_s3(filename):
    s3_hook = S3Hook(aws_conn_id='team3-2-s3-conn')
    s3_bucket = 'team3-2-s3'
    s3_key = 'tmdb_data/2023-2024-dramadata.json'
    s3_hook.load_file(
        filename=filename,
        key=s3_key,
        bucket_name=s3_bucket,
        replace=True
    )

@task
def save_to_redshift(filename):
    df = pd.read_json(filename)

    aws_conn_id = 'team3-2-redshift-conn'
    schema = 'public'  
    table = 'drama'  

    postgres_hook = PostgresHook(aws_conn_id=aws_conn_id)
    engine = create_engine(postgres_hook.get_uri())
    Session = sessionmaker(bind=engine)
    session = Session()

    df.to_sql(table, schema=schema, con=session.get_bind(), if_exists='replace', index=False)

    session.commit()
    session.close()


with DAG(
    dag_id='upload_drama_data_to_s3_and_save_to_redshift',
    start_date=datetime(2024, 3, 5),
    schedule_interval='@weekly',
    max_active_runs=1,
    catchup=False,
    default_args={
        'retries': 1,
        'retry_delay': timedelta(minutes=3),
    },
) as dag:

    # 태스크 실행
    filename = generate_movie_data()
    upload_to_s3(filename)
    save_to_redshift(filename)