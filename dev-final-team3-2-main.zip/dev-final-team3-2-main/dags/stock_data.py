from airflow import DAG
from airflow.operators.python import task
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.models import Variable
from airflow.utils.dates import days_ago
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import time
import FinanceDataReader as fdr
import pandas as pd

default_args = {
    'owner': 'team3-2',
    'start_date': days_ago(1),
}

stock_info = [('210120', '빅텐츠'), ('389140', '포바이포'), ('253450', '스튜디오드래곤'), ('200350', '래몽래인'), 
              ('036420', '콘텐트리중앙'), ('035900', 'JYP Ent.'), ('035760', 'CJ ENM'), ('048910', '대원미디어'), 
              ('054780', '키이스트'), ('122450', 'KX'), ('086980', '쇼박스'), ('241840', '에이스토리'), ('048550', 'SM C&C'), 
              ('322780', '코퍼스코리아'), ('034120', 'SBS'), ('051780', '큐로홀딩스'), ('432430', '와이랩'), ('035620', '바른손이앤에이'), 
              ('046390', '삼화네트웍스'), ('068050', '팬엔터테인먼트'), ('206560', '덱스터'), ('160550', 'NEW'), ('299900', '위지윅스 튜디오'),
              ('018700', '바른손'), ('036030', '케이티알파'), ('419530', 'SAMG엔터'), ('310200', '애니플러스'), ('317530', '캐리소프트'), 
              ('204630', '스튜오산타클로스'), ('289220', '자이언트스텝'), ('408900', '스튜디오미르'), ('173940', '에프엔씨엔터')]

with DAG('stock_info_to_s3_redshift', default_args=default_args, schedule_interval='@daily') as dag:

    @task
    def get_stock_data(stock_info):
        all_stock_data = []
        for item in stock_info:
            try:
                stock_data = fdr.DataReader(item[0], start='2023')
                stock_data['Code'] = item[0]
                stock_data['Name'] = item[1]
                stock_data = stock_data[['Code', 'Name', 'Open', 'High', 'Low', 'Close', 'Volume', 'Change']]
                stock_data.columns = ['stock_code', 'stock_name', 'open_price', 'high_price', 'low_price', 'close_price', 'volume', 'change_rate']
                all_stock_data.append(stock_data)
            except Exception as e:
                print(f"주가 정보 조회 중 오류 발생 {e}")

        combined_stock_data = pd.concat(all_stock_data)
        filename = '/tmp/2023-2024-stockdata.csv'
        combined_stock_data.to_csv(filename, encoding='utf-8-sig')
        return filename

    @task
    def save_to_s3(filename):
        s3_hook = S3Hook(aws_conn_id='team3-2-s3-conn')
        s3_bucket = 'team3-2-s3'
        s3_key = 'stock_data/2023-2024-stockdata.csv'
        s3_hook.load_file(
            filename=filename,
            key=s3_key,
            bucket_name=s3_bucket,
            replace=True
        )

    @task
    def save_to_redshift(filename):
        df = pd.read_csv(filename)

        aws_conn_id = 'team3-2-redshift-conn'
        schema = 'public'  
        table = 'stock'  

        postgres_hook = PostgresHook(aws_conn_id=aws_conn_id)
        engine = create_engine(postgres_hook.get_uri())
        Session = sessionmaker(bind=engine)
        session = Session()

        df.to_sql(table, schema=schema, con=session.get_bind(), if_exists='replace', index=False)

        session.commit()
        session.close()

    filename = get_stock_data(stock_info)
    save_to_s3(filename)
    save_to_redshift(filename)
