from airflow import DAG
from airflow.operators.python import task
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.utils.dates import days_ago
from bs4 import BeautifulSoup
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import requests
import pandas as pd
import datetime

default_args = {
    'owner': 'team3-2',
    'start_date': days_ago(1),
}

with DAG('drama_brand_reputation_to_s3', default_args=default_args, schedule_interval='@monthly') as dag:

    @task
    def get_brand_reputation():
        brand_reputation = []
        current_year = datetime.datetime.now().year
        current_month = datetime.datetime.now().month

        for year in range(2023, 2025):
            for month in range(1, 13):
                if year == current_year and month > current_month:
                    break
                url = f"https://brikorea.com/rk/drama{year%100}{month:02}"
                response = requests.get(url)
                soup = BeautifulSoup(response.text, 'html.parser')
                table = soup.find('table', class_='table table-bordered table-striped bri_rank_table')
                if table is None:
                    print(f"존재하지 않는 데이터 {year:02}{month:02}")
                    continue
                rows = table.find_all('tr')
                for row in rows:
                    cols = row.find_all('td')
                    if len(cols) > 3:
                        name = cols[1].text
                        score = int(cols[3].text.replace(',', ''))
                        brand_reputation.append({
                            'actor_name': name,
                            'date': f"{year:02}-{month:02}-01",
                            'reputation_rate': score
                        })
        df = pd.DataFrame(brand_reputation)
        filename = '/tmp/reputation_actor_drama.csv'  
        df.to_csv(filename, index=False)
        return filename

    @task
    def upload_to_s3(filename):
        s3_hook = S3Hook(aws_conn_id='team3-2-s3-conn')
        s3_bucket = 'team3-2-s3'
        s3_key = 'brand_reputation/reputation_actor_drama.csv'  
        s3_hook.load_file(
            filename=filename,
            key=s3_key,
            bucket_name=s3_bucket,
            replace=True
        )
        return filename

    @task
    def save_to_redshift(filename):
        df = pd.read_csv(filename)
        aws_conn_id = 'team3-2-redshift-conn'
        schema = 'public'
        table = 'reputation_actor_drama'  
        postgres_hook = PostgresHook(aws_conn_id=aws_conn_id)
        engine = create_engine(postgres_hook.get_uri())
        Session = sessionmaker(bind=engine)
        session = Session()
        df.to_sql(table, schema=schema, con=session.get_bind(), if_exists='append', index=False)
        session.commit()
        session.close()

    filename = get_brand_reputation()
    filename = upload_to_s3(filename)
    save_to_redshift(filename)
