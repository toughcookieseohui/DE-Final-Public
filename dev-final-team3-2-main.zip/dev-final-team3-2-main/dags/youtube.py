from airflow import DAG
from airflow.decorators import task
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.models import Variable
from airflow.utils.dates import days_ago
import requests
import pandas as pd
import json
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

default_args = {
    'owner': 'team3-2',
    'start_date': days_ago(1),
}

with DAG('youtube_stats_to_redshift', default_args=default_args, schedule_interval='@weekly', catchup=False) as dag:

    @task
    def get_drama_movie_titles():
        s3_hook = S3Hook(aws_conn_id='team3-2-s3-conn')
        bucket = 'team3-2-s3'
        drama_key = 'tmdb_data/2023-dramadata.json'
        movie_key = 'tmdb_data/2023-moviedata.json'

        drama_file_obj = s3_hook.get_key(drama_key, bucket)
        drama_file_content = drama_file_obj.get()['Body'].read()
        drama_data = json.loads(drama_file_content)
        drama_titles = [item['name'] for item in drama_data]

        movie_file_obj = s3_hook.get_key(movie_key, bucket)
        movie_file_content = movie_file_obj.get()['Body'].read()
        movie_data = json.loads(movie_file_content)
        movie_titles = [item['original_title'] for item in movie_data]

        kw_list = drama_titles + movie_titles

        return kw_list

    @task
    def get_youtube_stats(kw_list):
        search_url = "https://www.googleapis.com/youtube/v3/search"
        videos_url = "https://www.googleapis.com/youtube/v3/videos"
        api_key = Variable.get('youtube_api_key')
        stats = []

        for kw in kw_list:
            search_params = {
                'part': 'snippet',
                'maxResults': 5,
                'q': f'{kw} 영화',
                'key': api_key
            }

            response = requests.get(search_url, params=search_params)

            if response.status_code == 200:
                data = response.json()
                video_ids = [item['id']['videoId'] for item in data['items'] if item['id']['kind'] == 'youtube#video']

                for video_id in video_ids:
                    videos_params = {
                        'part': 'statistics',
                        'id': video_id,
                        'key': api_key
                    }
                    response = requests.get(videos_url, params=videos_params)

                    if response.status_code == 200:
                        data = response.json()
                        statistics = data['items'][0]['statistics']
                        stats.append({
                            'Keyword': kw,
                            'Video ID': video_id,
                            'View Count': statistics.get('viewCount', 'N/A'),
                            'Like Count': statistics.get('likeCount', 'N/A'),
                            'Comment Count': statistics.get('commentCount', 'N/A')
                        })

        return stats

    @task
    def save_to_csv(stats):
        filename = '/tmp/youtube_stats.csv'
        df = pd.DataFrame(stats)
        df.to_csv(filename, index=False)
        return filename

    @task
    def save_to_redshift(filename):
        df = pd.read_csv(filename)

        aws_conn_id = 'team3-2-redshift-conn'
        schema = 'public'
        table = 'youtube_stats'  

        postgres_hook = PostgresHook(aws_conn_id=aws_conn_id)
        engine = create_engine(postgres_hook.get_uri().replace("postgres", "postgresql+psycopg2", 1))
        Session = sessionmaker(bind=engine)
        session = Session()
        df.to_sql(table, schema=schema, con=session.get_bind(), if_exists='replace', index=False)

        session.commit()
        session.close()

    kw_list = get_drama_movie_titles()
    stats = get_youtube_stats(kw_list)
    filename = save_to_csv(stats)
    save_to_redshift(filename)

